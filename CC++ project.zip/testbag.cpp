#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
int HP, coin, bag[4][100]={0};
void equipment ()
{
	bool keeppocketopen=true;
	while (keeppocketopen) {
		printf ("HP: %d\t\t\tCoin: %d\n", HP, coin);
		int count=0;
		while (count<1) {
			if (count%5==0) puts("");
			if (bag[0][0]) {printf ("Sword"); count++;}
		}
		printf("\n\n");
		puts ("0. Confirm\n1. Ehh...\nClose pocket? ");
		int option;
		scanf ("%d", &option);
		printf ("\e[1;1H\e[2J");
		if (option==0) break;
	}
}
void food ()
{
	bool keeppocketopen=true;
	while (keeppocketopen) {
		printf ("HP: %d\t\t\tCoin: %d\n", HP, coin);
		int count=0, *temp[]={0};
		while (count<6) {
			if (count%5==0) puts("");
			if (bag[1][0]) {printf ("%d. %5s: %d          ", count, "Apple", bag[1][0]); temp[count]=&bag[1][0]; count++;}
			if (bag[1][1]) {printf ("%d. %5s: %d          ", count, "Berry", bag[1][1]); temp[count]=&bag[1][1]; count++;}
			if (bag[1][2]) {printf ("%d. %10s: %d     ", count, "Small fish", bag[1][2]); temp[count]=&bag[1][2]; count++;}
			if (bag[1][3]) {printf ("%d. %11s: %d    ", count, "Medium fish", bag[1][3]); temp[count]=&bag[1][3]; count++;}
			if (bag[1][4]) {printf ("%d. %10s: %d     ", count, "Large fish", bag[1][4]); temp[count]=&bag[1][4]; count++;}
			if (bag[1][5]) {printf ("%d. %8s: %d     ", count, "Raw fish", bag[1][5]); temp[count]=&bag[1][5]; count++;}
			break;
		}
		printf("\n\n");
		printf ("%d. Nothing\nYou want to consume ", count);
		int option;
		scanf ("%d", &option);
		printf ("\e[1;1H\e[2J"); printf ("HP: %d\t\t\tCoin: %d\n", HP, coin); sleep(1);
		if (temp[option]==&bag[1][1]) {
			bag[1][1]--;
			int consume=rand()%10;
			if (consume==0) {puts("The berry was rotten"); sleep(2); puts("-3 HP"); sleep(2); printf ("\e[1;1H\e[2J"); HP-=3;}
			else { consume=rand()%2+2; puts("Fresh berry"); sleep(2); printf("+%d HP", consume); sleep(2); printf ("\e[1;1H\e[2J"); HP+=consume; if (HP>100) HP=100;}
		}
		if (option==count) {
			printf ("0. Confirm\n1. Ehh...\nClose pocket?\n");
			scanf ("%d", &option);
			printf ("\e[1;1H\e[2J");
			if (option==0) break;
		}
	}
}
void material ()
{
	bool keeppocketopen=true;
	while (keeppocketopen) {
		printf ("HP: %d\t\t\tCoin: %d\n", HP, coin);
		int count=0;
		while (count<2) {
			if (count%5==0) puts("");
			if (bag[2][0]) {printf ("%4s: %d      ", "Clay", bag[2][0]); count++;}
			if (bag[2][1]) {printf ("%5s: %d     ", "Stone", bag[2][1]); count++;}
			break;
		}
		printf("\n\n");
		puts ("0. Confirm\n1. Ehh...\nClose pocket?\n");
		int option;
		scanf ("%d", &option);
		printf ("\e[1;1H\e[2J");
		if (option==0) break;
	}
}
void goods (int &enemyHP)
{
	bool keeppocketopen=true;
	while (keeppocketopen) {
		printf ("HP: %d\t\t\tCoin: %d\n", HP, coin);
		int count=0, *temp[]={0};
		while (count<2) {
			if (count%5==0) puts("");
			if (bag[3][0]) {printf ("%d. %4s: %d         ", count, "Rock", bag[3][0]); temp[count]=&bag[3][0]; count++;}
			if (bag[3][1]) {printf ("%d. %4s: %d         ", count, "Bomb", bag[3][1]); temp[count]=&bag[3][1]; count++;}
			break;
		}
		printf("\n\n");
		printf ("%d. Nothing\nYou want to consume ", count);
		int option, missrate=rand()%20;
		scanf ("%d", &option);
		printf ("\e[1;1H\e[2J"); printf ("HP: %d\t\t\tCoin: %d\n", HP, coin); sleep(1);
		if (missrate==0) {
			printf ("."); sleep(1); printf ("."); sleep(1); printf ("."); sleep(1); puts("");
			puts("As expected"); sleep(2);
			puts("Due to your bad throwing skill"); sleep(2);
			puts("The thing you threw flys over the enemy and lands on a point far away from the enemy..."); sleep(2);
			puts("welp..."); sleep(2);
			printf ("\e[1;1H\e[2J");
		} else {
			if (temp[option]==&bag[3][0]) {
				bag[3][0]--;
				printf("You throw a rock and it hits enemy's head and does 4 damage"); sleep(3); printf ("\e[1;1H\e[2J"); enemyHP-=4;
			}
		if (option==count) {
			printf ("0. Confirm\n1. Ehh...\nClose pocket?\n");
			scanf ("%d", &option);
			printf ("\e[1;1H\e[2J");
			if (option==0) break;
		}
		  }
	}
}
void openbag (int enemyHP)
{
	bool keepbagopen=true;
	while (keepbagopen) {
		printf ("HP: %d\t\t\tCoin: %d\n", HP, coin);
		printf ("0. Nothing\n1. Equipment\n2. Food\n3. Material\n4. Goods\nMaybe open the pocket of ");
		int option;
		scanf ("%d", &option);
		printf ("\e[1;1H\e[2J");
		if (option==1) equipment();
		if (option==2) food();
		if (option==3) material();
		if (option==4) goods(enemyHP);
		if (option==0) {
			printf ("HP: %d\t\t\tCoin: %d\n", HP, coin);
			printf ("0. Confirm\n1. Wait\nClose bag?\n");
			scanf ("%d", &option);
			printf ("\e[1;1H\e[2J");
			if (option==0) break;
		}
	}
	printf ("\e[1;1H\e[2J"); printf ("HP: %d\n", HP); sleep(1);
}
int main (void)
{
	HP=100; coin=0; 
	int snakeHP=30;
	bag[0][0]=1; bag[2][0]=2; bag[2][1]=4; bag[1][0]=2; bag[1][1]=15; bag[1][5]=1; bag[3][0]=3;
	srand(time(NULL));
	puts ("0. Open bag");
	printf ("You want to ");
	int option;
	scanf ("%d", &option);
	printf ("\e[1;1H\e[2J"); sleep(1);
	if (option==0) openbag (snakeHP);
}
